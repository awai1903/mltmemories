import { useState } from 'react';
import { ArrowRight, Menu, Search, Shield, X } from 'lucide-react';

export const Header = () => {
  const [open, setOpen] = useState(false);
  const [search, setSearch] = useState(false);
  return <header className="absolute inset-x-0 top-0 z-30 flex items-center justify-between px-6 py-6 text-[#d8c5a3] md:px-[5%]">
    <a href="#home" className="flex items-center gap-3"><div className="relative flex h-14 w-12 items-center justify-center"><Shield className="h-12 w-12 text-[#c6a06a]" strokeWidth={1}/><span className="absolute text-xl">⚜</span></div><span className="text-sm tracking-[0.15em]">MUST<br/>BS MLT BOYS</span></a>
    <nav className="hidden items-center gap-10 text-sm lg:flex">{['Home','Our Journey','Memory Wall','The Boys','Time Capsule','Legacy'].map((item,i)=><a key={item} href={i === 0 ? '#home' : '#memories'} className={i===0 ? 'border-b border-[#d8b477] py-4 text-[#f1dfb5]' : 'py-4 text-stone-400 transition-colors hover:text-[#e4bc7c]'}>{item}</a>)}</nav>
    <div className="flex items-center gap-6"><button aria-label="Search memories" onClick={()=>setSearch(!search)}><Search className="h-5 w-5" strokeWidth={1.4}/></button><a href="#memories" className="hidden items-center gap-4 rounded-full border border-[#dbb77f] px-7 py-3 text-sm sm:flex">Explore <ArrowRight size={17} strokeWidth={1}/></a><button className="lg:hidden" aria-label="Toggle menu" onClick={()=>setOpen(!open)}>{open?<X/>:<Menu/>}</button></div>
    {open&&<nav className="absolute left-6 right-6 top-24 flex flex-col gap-5 rounded-lg border border-[#b79055]/30 bg-[#06101b] p-6">{['Home','Our Journey','Memory Wall','The Boys','Time Capsule','Legacy'].map(x=><a key={x} onClick={()=>setOpen(false)} href="#memories">{x}</a>)}</nav>}
    {search&&<form onSubmit={e=>{e.preventDefault();setSearch(false);document.getElementById('memories')?.scrollIntoView({behavior:'smooth'});}} className="absolute right-6 top-24 flex gap-3 rounded-full border border-[#b79055]/50 bg-[#07111d] px-5 py-3"><input autoFocus placeholder="Find your memories…" className="w-48 bg-transparent text-sm text-white outline-none"/><button aria-label="Submit search"><ArrowRight size={18}/></button></form>}
  </header>;
};