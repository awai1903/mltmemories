import { useRef, useState } from 'react';

const portraits = ['young man sunglasses','man black shirt','man portrait outdoors','student portrait','man casual portrait','man white shirt','man dark jacket','young man outdoors','man sunglasses portrait','male student','man mountain portrait','man leather jacket'];

export const PortraitOrbit = () => {
  const [rotation, setRotation] = useState(0);
  const [dragging, setDragging] = useState(false);
  const pointer = useRef<number | null>(null);
  const lastX = useRef(0);
  const cards = portraits.map((query,index)=>{
    const angle = (index * 30 + 90 + rotation) * Math.PI / 180;
    const depth = Math.sin(angle);
    return {query,index,depth,x:700+482*Math.cos(angle),y:255+168*depth,scale:0.62+(depth+1)*0.25,tilt:-23*Math.cos(angle),width:0.65+0.35*Math.abs(depth)};
  }).sort((a,b)=>a.depth-b.depth);
  const badge = <g transform="translate(700 258)" className="pointer-events-none"><circle r="97" fill="#020912" stroke="url(#gold)" strokeWidth="2"/><circle r="104" fill="none" stroke="#bb7d34" strokeWidth="6" opacity="0.3" filter="url(#glow)"/><circle r="89" fill="none" stroke="#95703c" strokeOpacity="0.3"/><path d="M-43 -28h22l5 -7 5 18 5 -43 6 54 6 -28 5 10 6 -7h23" fill="none" stroke="#e6be80" strokeWidth="1.7"/><text y="22" textAnchor="middle" fill="#dcb47c" fontSize="25" letterSpacing="2">BS MLT</text><text y="50" textAnchor="middle" fill="#dcb47c" fontSize="24" letterSpacing="2">BOYS</text></g>;
  const renderCard = (card: typeof cards[number]) => <g key={card.index} transform={`translate(${card.x} ${card.y}) rotate(${card.tilt}) scale(${card.scale*card.width} ${card.scale})`} opacity={0.55+(card.depth+1)*0.225}>
    <rect x="-77" y="-99" width="154" height="198" rx="13" fill="#dc9c4d" opacity="0.24" filter="url(#glow)"/>
    <rect x="-73" y="-95" width="146" height="190" rx="11" fill="#101b22" stroke="url(#gold)" strokeWidth="3"/>
    <image href={`https://csspicker.dev/api/image/?q=${card.query.replaceAll(' ','+')}&image_type=photo`} x="-71" y="-93" width="142" height="186" preserveAspectRatio="xMidYMid slice" clipPath="url(#portrait-clip)"/>
    {card.depth < 0 && <rect x="-71" y="-93" width="142" height="186" rx="9" fill="#020912" opacity={-card.depth*0.32}/>}
  </g>;
  return <div className="mx-auto w-full max-w-[1440px] px-1 sm:px-5">
    <svg viewBox="35 0 1330 620" role="slider" tabIndex={0} aria-label="Picture ring. Swipe or drag to rotate the 12 pictures, or use left and right arrow keys." aria-valuemin={0} aria-valuemax={360} aria-valuenow={Math.round((rotation%360+360)%360)} onKeyDown={e=>{if(e.key==='ArrowLeft'||e.key==='ArrowRight'){e.preventDefault();setRotation(r=>r+(e.key==='ArrowRight'?30:-30));}}} className={`w-full touch-none select-none outline-none focus-visible:rounded-3xl focus-visible:ring-1 focus-visible:ring-[#c5a16b]/50 ${dragging?'cursor-grabbing':'cursor-grab'}`} onPointerDown={e=>{if(pointer.current!==null || (e.pointerType==='mouse'&&e.button!==0))return;pointer.current=e.pointerId;lastX.current=e.clientX;setDragging(true);e.currentTarget.setPointerCapture(e.pointerId);}} onPointerMove={e=>{if(pointer.current!==e.pointerId)return;const width=e.currentTarget.getBoundingClientRect().width;const delta=(e.clientX-lastX.current)*180/Math.max(width,1);lastX.current=e.clientX;setRotation(r=>(r-delta)%360);}} onPointerUp={e=>{if(pointer.current===e.pointerId){pointer.current=null;setDragging(false);if(e.currentTarget.hasPointerCapture(e.pointerId))e.currentTarget.releasePointerCapture(e.pointerId);}}} onPointerCancel={()=>{pointer.current=null;setDragging(false);}} onLostPointerCapture={()=>{pointer.current=null;setDragging(false);}}>
      <defs>
        <radialGradient id="halo"><stop offset="0" stopColor="#b77b32" stopOpacity="0"/><stop offset="0.7" stopColor="#ba7a2f" stopOpacity="0.02"/><stop offset="0.88" stopColor="#bf853c" stopOpacity="0.17"/><stop offset="1" stopColor="#ba7a2f" stopOpacity="0"/></radialGradient>
        <linearGradient id="gold" x1="0" y1="0" x2="1" y2="1"><stop stopColor="#9a652e"/><stop offset="0.25" stopColor="#ffe0a0"/><stop offset="0.52" stopColor="#aa763b"/><stop offset="0.8" stopColor="#f5c277"/><stop offset="1" stopColor="#b57c35"/></linearGradient>
        <filter id="glow" x="-50%" y="-50%" width="200%" height="200%"><feGaussianBlur stdDeviation="5"/></filter>
        <filter id="spark"><feGaussianBlur stdDeviation="1.6"/></filter>
        <clipPath id="portrait-clip"><rect x="-71" y="-93" width="142" height="186" rx="9"/></clipPath>
      </defs>
      <ellipse cx="700" cy="333" rx="605" ry="257" fill="url(#halo)"/>
      {[0,1,2,3,4].map(i=><g key={i}><ellipse cx="700" cy={302+i*6} rx={570-i*43} ry={235-i*22} fill="none" stroke="#cc8c3d" strokeWidth={i===0?6:3} opacity={i===0?0.4:0.15} filter="url(#glow)"/><ellipse cx="700" cy={302+i*6} rx={570-i*43} ry={235-i*22} fill="none" stroke="url(#gold)" strokeWidth={i===0?1.7:0.9} opacity={i===0?0.8:0.3}/></g>)}
      <ellipse cx="700" cy="340" rx="548" ry="220" fill="none" stroke="#b07834" strokeWidth="1" opacity="0.23"/>
      {cards.filter(card=>card.depth<0).map(renderCard)}
      {badge}
      {cards.filter(card=>card.depth>=0).map(renderCard)}
      <g className="pointer-events-none">{Array.from({length:52},(_,i)=>{const a=i*2.399;return <circle key={i} cx={700+Math.cos(a)*(505+(i%4)*15)} cy={328+Math.sin(a)*210} r={i%7===0?2.6:0.9} fill="#f8c273" opacity={i%3===0?0.9:0.35} filter={i%7===0?'url(#spark)':undefined}/>;})}
        {[[-470,100],[350,170],[-220,210],[540,-30]].map(([x,y],i)=><g key={i} transform={`translate(${700+x} ${306+y})`}><circle r="9" fill="#edb05b" opacity="0.5" filter="url(#glow)"/><path d="M-11 0H11M0 -13V13" stroke="#ffdea0" strokeWidth="0.9"/><circle r="2" fill="#fff0bf"/></g>)}
      </g>
    </svg>
  </div>;
};
