import { PortraitOrbit } from './components/PortraitOrbit';

const App = () => (
  <main className="flex min-h-screen items-center justify-center overflow-hidden bg-[#020810] font-[Georgia,serif]">
    <PortraitOrbit />
  </main>
);

export default App;
